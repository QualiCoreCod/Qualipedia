# Implantação da QualiPédia

Este repositório contém a aplicação React/Vite da QualiPédia. A interface pode ser trabalhada no Antigravity e publicada na Hostinger, enquanto autenticação e dados continuam no backend do Base44.

## 1. Preparar o projeto

Requisitos: Node.js 20 ou superior e npm.

```bash
npm install
cp .env.example .env.local
npm run build
```

As variáveis `VITE_BASE44_APP_ID` e `VITE_BASE44_APP_BASE_URL` são necessárias durante o build. Não adicione tokens ou senhas ao repositório.

## 2. Sincronizar os esquemas do Base44

Depois de vincular o repositório ao aplicativo correto no Base44 CLI, envie os esquemas de `base44/entities/` para o backend. Isso aplica as permissões de leitura pública, administração e acesso metodológico previstas no projeto.

O detalhamento técnico é armazenado na entidade `MethodologyDetail`. Não coloque pilares, critérios, pesos ou regras privadas diretamente em componentes React, porque tudo que entra no bundle do navegador pode ser lido sem login.

Para conceder acesso, um administrador deve definir `methodology_access=true` no usuário aprovado. Contas comuns permanecem sem acesso.

## 3. GitHub

Envie os arquivos-fonte do projeto, incluindo `src/`, `public/`, `base44/`, `package.json` e `package-lock.json`.

Não envie:

- `node_modules/`;
- `dist/`;
- `.env` ou `.env.local`;
- `dados/`, `Insumos/`, `biblioteca/` ou `documentos/`;
- planilhas, apresentações ou relatórios com dados profissionais reais.

Esses caminhos já estão protegidos pelo `.gitignore`.

## 4. Hostinger

### Deploy conectado ao GitHub

Use:

- comando de instalação: `npm ci`;
- comando de build: `npm run build`;
- diretório de publicação: `dist`.

Cadastre as variáveis de `.env.example` no painel de build da Hostinger.

### Upload manual

Execute o build localmente com as variáveis configuradas e envie **o conteúdo interno da pasta `dist/`** para `public_html`. O arquivo `.htaccess` gerado no build mantém as rotas internas da aplicação funcionando ao atualizar a página.

## 5. Validação antes da publicação

```bash
npm run lint
npm run typecheck
npm run build
```

Depois do deploy, teste:

1. página inicial, Enciclopédia, Guia de Decisão, ISO 9001, Métodos autorais e Sobre;
2. atualização direta das rotas internas;
3. login, logout e recuperação de senha;
4. usuário comum sem acesso ao detalhamento;
5. usuário aprovado com `methodology_access=true`;
6. administrador criando e editando conteúdo;
7. visualização em celular e desktop.
