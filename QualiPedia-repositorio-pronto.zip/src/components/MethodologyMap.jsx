import React from "react";
import {
  BadgeCheck,
  ChartNoAxesCombined,
  ChevronDown,
  CircleAlert,
  HeartHandshake,
  MessagesSquare,
  Route,
  Sparkles,
  Target,
  UserRoundCheck,
} from "lucide-react";

const AXES = [
  {
    title: "QA",
    label: "Qualidade técnica",
    description: "Avalia processo, tratativa, precisão, comunicação e conduta.",
    Icon: BadgeCheck,
  },
  {
    title: "IEPC",
    label: "Experiência percebida",
    description: "Observa resolução, clareza, esforço, fluidez e relação.",
    Icon: MessagesSquare,
  },
  {
    title: "Não conformidades",
    label: "Riscos e desvios",
    description: "Identifica ocorrências que exigem correção e prevenção.",
    Icon: CircleAlert,
  },
  {
    title: "Elogios",
    label: "Forças reconhecidas",
    description: "Registra comportamentos e entregas que merecem ser replicados.",
    Icon: Sparkles,
  },
];

const OUTPUTS = [
  { title: "Feedback", description: "Evidências e orientação", Icon: UserRoundCheck },
  { title: "Evolução", description: "Tendência e recorrência", Icon: ChartNoAxesCombined },
  { title: "PDI", description: "Ações de desenvolvimento", Icon: Target },
  { title: "Saúde do suporte", description: "Forças, riscos e prioridades", Icon: HeartHandshake },
];

export default function MethodologyMap({ compact = false }) {
  return (
    <div className={`surface-card overflow-hidden ${compact ? "p-5 md:p-6" : "p-5 md:p-8"}`}>
      <div className="flex items-center justify-between gap-4 border-b border-border pb-5">
        <div>
          <p className="eyebrow">Arquitetura da metodologia</p>
          <h2 className="mt-2 font-heading text-2xl font-bold tracking-tight md:text-3xl">Da evidência à melhoria</h2>
        </div>
        <span className="hidden h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-azul-claro text-destaque sm:flex">
          <Route className="h-6 w-6" />
        </span>
      </div>

      <div className="mt-6 grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        {AXES.map(({ title, label, description, Icon }, index) => (
          <article key={title} className="relative rounded-2xl border border-border bg-fundo p-5">
            <span className="absolute right-4 top-4 font-mono text-xs font-bold text-destaque/60">0{index + 1}</span>
            <span className="flex h-10 w-10 items-center justify-center rounded-xl border border-destaque/15 bg-white text-destaque shadow-sm">
              <Icon className="h-5 w-5" />
            </span>
            <h3 className="mt-4 text-lg font-bold">{title}</h3>
            <p className="mt-1 text-sm font-semibold text-petroleo">{label}</p>
            <p className="mt-2 text-sm leading-6 text-muted-foreground">{description}</p>
          </article>
        ))}
      </div>

      <div className="flex justify-center py-3 text-destaque" aria-hidden="true">
        <ChevronDown className="h-6 w-6" strokeWidth={2.5} />
      </div>

      <div className="grid gap-3 md:grid-cols-2">
        <div className="rounded-2xl bg-grafite p-5 text-white">
          <p className="text-xs font-bold uppercase tracking-[0.15em] text-white/60">Duas avaliações</p>
          <p className="mt-2 text-xl font-bold text-white">Nota QA + Nota IEPC</p>
          <p className="mt-2 text-sm leading-6 text-white/70">Duas leituras complementares: execução técnica e experiência percebida.</p>
        </div>
        <div className="rounded-2xl border border-destaque/20 bg-azul-claro p-5">
          <p className="text-xs font-bold uppercase tracking-[0.15em] text-destaque">Sinais complementares</p>
          <p className="mt-2 text-xl font-bold">Riscos + reconhecimento</p>
          <p className="mt-2 text-sm leading-6 text-petroleo">Não conformidades e elogios ajudam a explicar o resultado e orientar ações.</p>
        </div>
      </div>

      <div className="flex justify-center py-3 text-destaque" aria-hidden="true">
        <ChevronDown className="h-6 w-6" strokeWidth={2.5} />
      </div>

      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        {OUTPUTS.map(({ title, description, Icon }) => (
          <div key={title} className="rounded-xl border border-border bg-white p-4 shadow-[0_1px_2px_rgba(16,24,40,0.04)]">
            <Icon className="h-5 w-5 text-destaque" />
            <p className="mt-3 font-bold">{title}</p>
            <p className="mt-1 text-sm text-muted-foreground">{description}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
