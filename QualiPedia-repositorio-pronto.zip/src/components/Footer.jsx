import React from "react";
import { Link } from "react-router-dom";
import BrandLogo from "@/components/BrandLogo";

export default function Footer() {
  return (
    <footer className="border-t border-border bg-white">
      <div className="page-shell py-10 md:py-12">
        <div className="flex flex-col gap-8 md:flex-row md:items-start md:justify-between">
          <div className="max-w-sm">
            <BrandLogo />
            <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
              Conhecimento em gestão da qualidade, organizado para entender, decidir e aplicar.
            </p>
          </div>
          <nav aria-label="Navegação do rodapé" className="grid grid-cols-2 gap-x-8 gap-y-3 text-sm">
            <Link to="/enciclopedia" className="text-muted-foreground hover:text-destaque">Enciclopédia</Link>
            <Link to="/decisao" className="text-muted-foreground hover:text-destaque">Guia de decisão</Link>
            <Link to="/iso" className="text-muted-foreground hover:text-destaque">ISO 9001</Link>
            <Link to="/metodos" className="text-muted-foreground hover:text-destaque">Métodos autorais</Link>
          </nav>
        </div>
        <div className="mt-9 flex flex-col gap-1 border-t border-border pt-5 text-xs text-muted-foreground sm:flex-row sm:items-center sm:justify-between">
          <p>Projeto autoral — Bruna Silva Ramos</p>
          <p>© 2026 — Conteúdo, idealização e curadoria.</p>
        </div>
      </div>
    </footer>
  );
}
