import React, { useState } from "react";
import { Outlet, NavLink, useLocation, Link } from "react-router-dom";
import { useAuth } from "@/lib/AuthContext";
import { Menu, X, LogIn, LogOut } from "lucide-react";
import Footer from "@/components/Footer";
import BrandLogo from "@/components/BrandLogo";

const navItems = [
  { to: "/", label: "Início", end: true },
  { to: "/enciclopedia", label: "Enciclopédia" },
  { to: "/decisao", label: "Guia de decisão" },
  { to: "/iso", label: "ISO 9001" },
  { to: "/metodos", label: "Métodos autorais" },
  { to: "/sobre", label: "Sobre" },
];

export default function Layout() {
  const location = useLocation();
  const { isAuthenticated, isAdmin, logout } = useAuth();
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col">
      <a href="#conteudo-principal" className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-50 focus:rounded-lg focus:bg-grafite focus:px-4 focus:py-2 focus:text-sm focus:font-semibold focus:text-white">
        Pular para o conteúdo
      </a>
      {/* Header */}
      <header className="sticky top-0 z-40 border-b border-border/80 bg-white/92 shadow-[0_1px_0_rgba(16,24,40,0.02)] backdrop-blur-xl">
        <div className="page-shell">
          <div className="flex h-[72px] items-center justify-between gap-6">
            {/* Logo */}
            <Link to="/" aria-label="QualiPédia — página inicial" className="shrink-0 rounded-lg focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-destaque focus-visible:ring-offset-4">
              <BrandLogo />
            </Link>

            {/* Desktop nav */}
            <nav aria-label="Navegação principal" className="hidden xl:flex items-center gap-1">
              {navItems.map((item) => (
                <NavLink
                  key={item.label}
                  to={item.to}
                  end={item.end}
                  className={({ isActive }) =>
                    `rounded-lg px-3 py-2 text-sm font-medium transition-colors ${
                      isActive
                        ? "bg-azul-claro text-destaque"
                        : "text-muted-foreground hover:bg-fundo hover:text-grafite"
                    }`
                  }
                >
                  {item.label}
                </NavLink>
              ))}
            </nav>

            {/* Auth + Mobile toggle */}
            <div className="flex items-center gap-2">
              {isAdmin && (
                <Link to="/adicionar" className="hidden sm:inline-flex min-h-10 items-center rounded-lg px-3 text-sm font-medium text-petroleo hover:bg-azul-claro transition-colors">
                  Gerenciar
                </Link>
              )}
              {isAuthenticated ? (
                <button
                  onClick={() => logout()}
                  className="inline-flex min-h-10 items-center gap-2 rounded-lg border border-border bg-white px-3 text-sm font-semibold text-grafite hover:border-destaque/40 hover:text-destaque transition-colors"
                >
                  <LogOut className="h-4 w-4" /> <span className="hidden sm:inline">Sair</span>
                </button>
              ) : (
                <Link
                  to="/login"
                  className="inline-flex min-h-10 items-center gap-2 rounded-lg bg-destaque px-3.5 text-sm font-semibold text-white shadow-sm hover:bg-[#285fc3] transition-colors"
                >
                  <LogIn className="h-4 w-4" /> <span className="hidden sm:inline">Entrar</span>
                </Link>
              )}
              <button
                onClick={() => setMobileOpen(!mobileOpen)}
                className="xl:hidden inline-flex h-10 w-10 items-center justify-center rounded-lg text-muted-foreground hover:bg-fundo hover:text-foreground transition-colors"
                aria-expanded={mobileOpen}
                aria-controls="menu-mobile"
                aria-label={mobileOpen ? "Fechar menu" : "Abrir menu"}
              >
                {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
              </button>
            </div>
          </div>

          {/* Mobile nav */}
          {mobileOpen && (
            <nav id="menu-mobile" aria-label="Navegação mobile" className="xl:hidden border-t border-border py-4 space-y-1">
              {navItems.map((item) => (
                <NavLink
                  key={item.label}
                  to={item.to}
                  end={item.end}
                  onClick={() => setMobileOpen(false)}
                  className={({ isActive }) =>
                    `block min-h-11 px-3 py-2.5 text-base font-medium rounded-lg transition-colors ${
                      isActive
                        ? "text-destaque font-medium bg-azul-claro"
                        : "text-muted-foreground hover:text-foreground hover:bg-fundo"
                    }`
                  }
                >
                  {item.label}
                </NavLink>
              ))}
              {isAdmin && (
                <NavLink
                  to="/adicionar"
                  onClick={() => setMobileOpen(false)}
                  className="block min-h-11 rounded-lg px-3 py-2.5 text-base font-medium text-petroleo hover:bg-azul-claro"
                >
                  Gerenciar conteúdo
                </NavLink>
              )}
            </nav>
          )}
        </div>
      </header>

      {/* Main */}
      <main id="conteudo-principal" key={location.pathname} className="flex-1">
        <Outlet />
      </main>

      {/* Footer */}
      <Footer />
    </div>
  );
}
