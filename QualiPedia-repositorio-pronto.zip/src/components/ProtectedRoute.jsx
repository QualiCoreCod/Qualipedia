import { useEffect } from 'react';
import { Link, Outlet } from 'react-router-dom';
import { useAuth } from '@/lib/AuthContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';
import { ArrowLeft, ShieldX } from 'lucide-react';

const DefaultFallback = () => (
  <div className="fixed inset-0 flex items-center justify-center">
    <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin"></div>
  </div>
);

const DefaultUnauthorized = () => (
  <div className="reading-shell py-16 md:py-24">
    <div className="surface-card mx-auto max-w-xl p-7 text-center md:p-10">
      <span className="mx-auto flex h-12 w-12 items-center justify-center rounded-2xl bg-azul-claro text-destaque">
        <ShieldX className="h-6 w-6" />
      </span>
      <h1 className="mt-5 font-heading text-2xl font-bold tracking-tight">Acesso ainda não autorizado</h1>
      <p className="mt-3 text-base leading-relaxed text-muted-foreground">
        Sua conta está autenticada, mas o detalhamento técnico da metodologia exige uma autorização específica.
      </p>
      <Link to="/metodos" className="mt-6 inline-flex min-h-11 items-center gap-2 rounded-lg bg-destaque px-4 py-2.5 text-sm font-semibold text-white hover:bg-[#285fc3]">
        <ArrowLeft className="h-4 w-4" /> Voltar aos métodos autorais
      </Link>
    </div>
  </div>
);

export default function ProtectedRoute({
  fallback = <DefaultFallback />,
  unauthenticatedElement,
  unauthorizedElement = <DefaultUnauthorized />,
  requiredAccess = "authenticated",
}) {
  const {
    isAuthenticated,
    isAdmin,
    hasMethodologyAccess,
    isLoadingAuth,
    authChecked,
    authError,
    checkUserAuth,
  } = useAuth();

  useEffect(() => {
    if (!authChecked && !isLoadingAuth) {
      checkUserAuth();
    }
  }, [authChecked, isLoadingAuth, checkUserAuth]);

  if (isLoadingAuth || !authChecked) {
    return fallback;
  }

  if (authError) {
    if (authError.type === 'user_not_registered') {
      return <UserNotRegisteredError />;
    }
    return unauthenticatedElement;
  }

  if (!isAuthenticated) {
    return unauthenticatedElement;
  }

  if (requiredAccess === "admin" && !isAdmin) {
    return unauthorizedElement;
  }

  if (requiredAccess === "methodology" && !hasMethodologyAccess) {
    return unauthorizedElement;
  }

  return <Outlet />;
}
