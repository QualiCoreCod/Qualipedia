import React from "react";

export function BrandMark({ className = "h-9 w-9", title = "Marca QualiPédia" }) {
  return (
    <svg
      viewBox="0 0 48 48"
      className={className}
      role="img"
      aria-label={title}
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M37.6 31.6A17 17 0 1 0 31.2 38"
        stroke="#172033"
        strokeWidth="5"
        strokeLinecap="round"
      />
      <path
        d="M29.5 29.5 41 41"
        stroke="#356FD6"
        strokeWidth="5"
        strokeLinecap="round"
      />
      <circle cx="18" cy="18" r="3.5" fill="#356FD6" />
    </svg>
  );
}

export default function BrandLogo({ className = "", compact = false }) {
  return (
    <span className={`inline-flex items-center gap-2.5 ${className}`}>
      <BrandMark className="h-9 w-9 shrink-0" />
      {!compact && (
        <span className="font-heading text-[17px] font-bold tracking-[-0.025em] text-grafite">
          Quali<span className="text-destaque">Pédia</span>
        </span>
      )}
    </span>
  );
}
