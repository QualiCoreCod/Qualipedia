import React from "react";
import { Link } from "react-router-dom";
import {
  ArrowRight,
  BadgeCheck,
  BarChart3,
  BookOpenCheck,
  CircleAlert,
  Lightbulb,
  LockKeyhole,
  MessageSquareHeart,
  ShieldCheck,
  Sparkles,
  Target,
  TrendingUp,
  UserRoundCheck,
} from "lucide-react";
import { useAuth } from "@/lib/AuthContext";
import MethodologyMap from "@/components/MethodologyMap";

const AXES = [
  {
    number: "01",
    title: "Qualidade técnica",
    short: "QA",
    description: "Avalia se o atendimento foi conduzido com método, precisão, clareza e postura profissional.",
    topics: ["fluxo e rastreabilidade", "tratativa da demanda", "assertividade técnica", "comunicação e conduta"],
    Icon: BadgeCheck,
  },
  {
    number: "02",
    title: "Experiência percebida",
    short: "IEPC",
    description: "Observa como o cliente percebeu a resolução e o caminho percorrido durante a interação.",
    topics: ["resolução", "clareza e segurança", "esforço", "tempo, fluidez e relação"],
    Icon: MessageSquareHeart,
  },
  {
    number: "03",
    title: "Não conformidades",
    short: "NC",
    description: "Torna visíveis desvios e riscos que exigem correção imediata ou prevenção de recorrência.",
    topics: ["identificação do desvio", "análise de risco", "ação corretiva", "prevenção"],
    Icon: CircleAlert,
  },
  {
    number: "04",
    title: "Elogios",
    short: "Reconhecimento",
    description: "Registra forças percebidas para reconhecer boas práticas e ampliar comportamentos positivos.",
    topics: ["evidência positiva", "comportamento replicável", "reconhecimento", "desenvolvimento"],
    Icon: Sparkles,
  },
];

const OUTPUTS = [
  {
    title: "Feedback mensal",
    description: "Uma conversa estruturada por evidências, com pontos fortes e oportunidades claras.",
    Icon: UserRoundCheck,
  },
  {
    title: "Evolução",
    description: "Leitura de tendência, recorrência e consolidação de novos comportamentos ao longo dos ciclos.",
    Icon: TrendingUp,
  },
  {
    title: "PDI",
    description: "Ações de desenvolvimento conectadas às causas e às competências que precisam evoluir.",
    Icon: Target,
  },
  {
    title: "Saúde do suporte",
    description: "Visão agregada das forças, riscos, gargalos e prioridades de prevenção da operação.",
    Icon: BarChart3,
  },
];

const CREATION_STEPS = [
  {
    label: "Diagnosticar",
    description: "Entender o cenário, os riscos, a falta de padrão e as perguntas que a avaliação precisa responder.",
  },
  {
    label: "Estruturar",
    description: "Transformar o diagnóstico em pilares, critérios, evidências e regras de leitura consistentes.",
  },
  {
    label: "Medir",
    description: "Gerar duas avaliações complementares e registrar sinais positivos e desvios relevantes.",
  },
  {
    label: "Desenvolver",
    description: "Converter os achados em feedback, evolução, PDI e decisões preventivas para o suporte.",
  },
];

export default function Materials() {
  const { isAuthenticated, hasMethodologyAccess } = useAuth();
  const detailsHref = hasMethodologyAccess
    ? "/metodos/atendimento/detalhes"
    : `/login?returnTo=${encodeURIComponent("/metodos/atendimento/detalhes")}`;

  return (
    <div className="pb-16 md:pb-24">
      <section className="relative overflow-hidden border-b border-border bg-white">
        <div className="absolute inset-y-0 right-0 hidden w-[38%] bg-[linear-gradient(135deg,#F5F7FA_0%,#EAF1F8_100%)] lg:block" aria-hidden="true" />
        <div className="page-shell relative grid gap-10 py-12 md:py-16 lg:grid-cols-[1.25fr_0.75fr] lg:items-center lg:py-20">
          <div>
            <p className="eyebrow">Métodos autorais</p>
            <h1 className="page-title mt-4 max-w-4xl">
              Metodologia de Qualidade para Atendimento e Suporte ao Cliente
            </h1>
            <p className="page-lede mt-6">
              Um método autoral que integra qualidade técnica, experiência percebida, prevenção de riscos e reconhecimento para transformar atendimentos em desenvolvimento contínuo.
            </p>
            <div className="mt-7 flex flex-wrap gap-2" aria-label="Características da metodologia">
              {["Framework autoral", "QA + IEPC", "Melhoria contínua", "Aplicável a suporte"].map((item) => (
                <span key={item} className="rounded-full border border-border bg-fundo px-3 py-1.5 text-sm font-medium text-petroleo">
                  {item}
                </span>
              ))}
            </div>
            <div className="mt-8 flex flex-col gap-3 sm:flex-row sm:items-center">
              {hasMethodologyAccess || !isAuthenticated ? (
                <Link to={detailsHref} className="inline-flex min-h-12 items-center justify-center gap-2 rounded-xl bg-destaque px-5 py-3 text-sm font-bold text-white shadow-sm transition-colors hover:bg-[#285fc3]">
                  <LockKeyhole className="h-4 w-4" />
                  {hasMethodologyAccess ? "Ver detalhamento técnico" : "Entrar para acessar detalhes"}
                </Link>
              ) : (
                <div className="inline-flex min-h-12 items-center gap-2 rounded-xl border border-border bg-fundo px-5 py-3 text-sm font-semibold text-muted-foreground">
                  <ShieldCheck className="h-4 w-4 text-destaque" /> Acesso técnico sujeito à aprovação
                </div>
              )}
              <a href="#visao-geral" className="inline-flex min-h-12 items-center justify-center gap-2 rounded-xl border border-border bg-white px-5 py-3 text-sm font-bold text-grafite transition-colors hover:border-destaque/40 hover:text-destaque">
                Entender a metodologia <ArrowRight className="h-4 w-4" />
              </a>
            </div>
          </div>

          <div className="surface-card relative p-6 md:p-8">
            <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-azul-claro text-destaque">
              <BookOpenCheck className="h-6 w-6" />
            </span>
            <p className="mt-6 text-sm font-bold uppercase tracking-[0.15em] text-destaque">O que esta página mostra</p>
            <p className="mt-3 text-xl font-bold leading-snug text-grafite">A lógica, os quatro eixos e as entregas da metodologia.</p>
            <p className="mt-3 text-sm leading-6 text-muted-foreground">
              Critérios, pesos, fórmulas e exemplos técnicos ficam na camada autorizada. Dados reais de empresas ou pessoas não fazem parte da QualiPédia.
            </p>
          </div>
        </div>
      </section>

      <section id="visao-geral" className="page-shell scroll-mt-24 py-12 md:py-16">
        <div className="max-w-3xl">
          <p className="eyebrow">Visão geral</p>
          <h2 className="mt-3 font-heading text-3xl font-bold tracking-tight md:text-4xl">Uma metodologia, quatro lentes</h2>
          <p className="mt-4 text-lg leading-8 text-muted-foreground">
            A qualidade do suporte não cabe em uma nota isolada. Por isso, o método combina a execução técnica com a experiência do cliente e usa riscos e elogios para explicar o contexto de cada resultado.
          </p>
        </div>
        <div className="mt-8">
          <MethodologyMap />
        </div>
      </section>

      <section className="border-y border-border bg-white">
        <div className="page-shell py-12 md:py-16">
          <div className="max-w-3xl">
            <p className="eyebrow">Os quatro eixos</p>
            <h2 className="mt-3 font-heading text-3xl font-bold tracking-tight md:text-4xl">O que cada lente ajuda a compreender</h2>
          </div>
          <div className="mt-8 grid gap-4 lg:grid-cols-2">
            {AXES.map(({ number, title, short, description, topics, Icon }) => (
              <article key={title} className="group rounded-2xl border border-border bg-white p-6 shadow-[0_1px_2px_rgba(16,24,40,0.04)] transition-all hover:-translate-y-0.5 hover:border-destaque/35 hover:shadow-[0_12px_28px_rgba(16,24,40,0.08)]">
                <div className="flex items-start justify-between gap-4">
                  <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-azul-claro text-destaque">
                    <Icon className="h-5 w-5" />
                  </span>
                  <span className="font-mono text-sm font-bold text-destaque/55">{number}</span>
                </div>
                <p className="mt-5 text-xs font-bold uppercase tracking-[0.15em] text-destaque">{short}</p>
                <h3 className="mt-2 text-2xl font-bold">{title}</h3>
                <p className="mt-3 text-base leading-7 text-muted-foreground">{description}</p>
                <div className="mt-5 flex flex-wrap gap-2">
                  {topics.map((topic) => (
                    <span key={topic} className="rounded-full bg-fundo px-3 py-1.5 text-sm text-petroleo">{topic}</span>
                  ))}
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="page-shell py-12 md:py-16">
        <div className="grid gap-10 lg:grid-cols-[0.85fr_1.15fr] lg:items-start">
          <div className="lg:sticky lg:top-28">
            <p className="eyebrow">Construção do método</p>
            <h2 className="mt-3 font-heading text-3xl font-bold tracking-tight md:text-4xl">Do diagnóstico ao desenvolvimento</h2>
            <p className="mt-4 text-lg leading-8 text-muted-foreground">
              A estrutura foi criada com raciocínio de melhoria contínua: entender o problema, transformar o cenário em critérios, medir com consistência e agir sobre as causas.
            </p>
          </div>
          <ol className="space-y-4">
            {CREATION_STEPS.map((step, index) => (
              <li key={step.label} className="surface-card flex gap-4 p-5 md:p-6">
                <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-grafite font-mono text-sm font-bold text-white">{index + 1}</span>
                <div>
                  <h3 className="text-xl font-bold">{step.label}</h3>
                  <p className="mt-2 text-base leading-7 text-muted-foreground">{step.description}</p>
                </div>
              </li>
            ))}
          </ol>
        </div>
      </section>

      <section className="border-y border-border bg-grafite text-white">
        <div className="page-shell py-12 md:py-16">
          <div className="max-w-3xl">
            <p className="text-xs font-bold uppercase tracking-[0.16em] text-[#8FB4F8]">O que o ciclo produz</p>
            <h2 className="mt-3 font-heading text-3xl font-bold tracking-tight !text-white md:text-4xl">A avaliação termina em ação</h2>
            <p className="mt-4 text-lg leading-8 text-white/70">
              O objetivo não é classificar pessoas. É tornar evidências compreensíveis e úteis para o desenvolvimento individual e para a gestão preventiva do suporte.
            </p>
          </div>
          <div className="mt-8 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
            {OUTPUTS.map(({ title, description, Icon }) => (
              <article key={title} className="rounded-2xl border border-white/10 bg-white/[0.06] p-5">
                <Icon className="h-6 w-6 text-[#8FB4F8]" />
                <h3 className="mt-5 text-xl font-bold !text-white">{title}</h3>
                <p className="mt-2 text-sm leading-6 text-white/70">{description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="page-shell py-12 md:py-16">
        <div className="surface-card grid overflow-hidden lg:grid-cols-2">
          <div className="p-6 md:p-9">
            <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-azul-claro text-destaque">
              <Lightbulb className="h-5 w-5" />
            </span>
            <p className="mt-5 eyebrow">Conteúdo público</p>
            <h2 className="mt-3 text-2xl font-bold md:text-3xl">Conhecimento para compreender e adaptar</h2>
            <p className="mt-4 text-base leading-7 text-muted-foreground">
              A visão geral, os eixos, o fluxo e as entregas ficam disponíveis para qualquer visitante. O conteúdo usa linguagem genérica e pode inspirar aplicações em outros contextos.
            </p>
          </div>
          <div className="border-t border-border bg-fundo p-6 md:p-9 lg:border-l lg:border-t-0">
            <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-white text-destaque shadow-sm">
              <LockKeyhole className="h-5 w-5" />
            </span>
            <p className="mt-5 eyebrow">Conteúdo autorizado</p>
            <h2 className="mt-3 text-2xl font-bold md:text-3xl">Detalhes técnicos, sem dados reais</h2>
            <p className="mt-4 text-base leading-7 text-muted-foreground">
              A camada autenticada reúne pilares, critérios, pesos, regras e exemplos fictícios. Nenhuma área do site exibe informações de empresa, clientes, colaboradores ou atendimentos reais.
            </p>
            {hasMethodologyAccess || !isAuthenticated ? (
              <Link to={detailsHref} className="mt-6 inline-flex min-h-11 items-center gap-2 font-bold text-destaque hover:underline">
                {hasMethodologyAccess ? "Abrir detalhes técnicos" : "Entrar para verificar acesso"} <ArrowRight className="h-4 w-4" />
              </Link>
            ) : (
              <p className="mt-6 inline-flex items-center gap-2 text-sm font-semibold text-muted-foreground">
                <ShieldCheck className="h-4 w-4 text-destaque" /> Sua conta aguarda autorização para esta camada.
              </p>
            )}
          </div>
        </div>
      </section>
    </div>
  );
}
