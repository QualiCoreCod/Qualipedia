import React, { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import {
  ArrowLeft,
  BookOpenCheck,
  Database,
  LockKeyhole,
  ShieldCheck,
} from "lucide-react";
import MethodologyMap from "@/components/MethodologyMap";
import { base44 } from "@/api/base44Client";

const SECTION_ORDER = [
  "QA",
  "IEPC",
  "Não conformidades",
  "Elogios",
  "Pontuação",
  "Exemplo didático",
];

function SectionCard({ record }) {
  const items = Array.isArray(record.items) ? record.items : [];

  return (
    <article className="surface-card overflow-hidden">
      <div className="border-b border-border bg-fundo p-5 md:p-6">
        <p className="eyebrow">{record.section}</p>
        <h2 className="mt-2 text-2xl font-bold tracking-tight md:text-3xl">{record.title}</h2>
        {record.description && (
          <p className="mt-3 max-w-4xl text-base leading-7 text-muted-foreground">
            {record.description}
          </p>
        )}
      </div>

      {items.length > 0 && (
        <div className="divide-y divide-border">
          {items.map((item, index) => (
            <div key={`${record.id}-${item.code || index}`} className="grid gap-3 p-5 md:grid-cols-[90px_1fr_auto] md:items-start md:px-6">
              <span className="w-fit rounded-lg bg-azul-claro px-2.5 py-1 font-mono text-xs font-bold text-destaque">
                {item.code || String(index + 1).padStart(2, "0")}
              </span>
              <div>
                <h3 className="font-bold text-grafite">{item.label}</h3>
                {item.description && (
                  <p className="mt-1 text-sm leading-6 text-muted-foreground">{item.description}</p>
                )}
              </div>
              {typeof item.weight === "number" && (
                <span className="w-fit rounded-full border border-destaque/20 bg-white px-3 py-1 text-sm font-bold text-destaque">
                  {item.weight} pontos
                </span>
              )}
            </div>
          ))}
        </div>
      )}
    </article>
  );
}

export default function MethodologyDetails() {
  const [records, setRecords] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [loadError, setLoadError] = useState("");

  useEffect(() => {
    let active = true;

    base44.entities.MethodologyDetail.list("sort_order", 100)
      .then((data) => {
        if (active) setRecords(Array.isArray(data) ? data : []);
      })
      .catch(() => {
        if (active) setLoadError("Não foi possível carregar o detalhamento autorizado agora.");
      })
      .finally(() => {
        if (active) setIsLoading(false);
      });

    return () => {
      active = false;
    };
  }, []);

  const orderedRecords = useMemo(() => [...records].sort((a, b) => {
    const sectionA = SECTION_ORDER.indexOf(a.section);
    const sectionB = SECTION_ORDER.indexOf(b.section);
    if (sectionA !== sectionB) return sectionA - sectionB;
    return (a.sort_order || 0) - (b.sort_order || 0);
  }), [records]);

  return (
    <div className="pb-16 md:pb-24">
      <header className="border-b border-border bg-white">
        <div className="page-shell py-10 md:py-14">
          <Link to="/metodos" className="inline-flex min-h-11 items-center gap-2 text-sm font-bold text-muted-foreground hover:text-destaque">
            <ArrowLeft className="h-4 w-4" /> Métodos autorais
          </Link>
          <div className="mt-7 flex flex-col gap-7 lg:flex-row lg:items-end lg:justify-between">
            <div className="max-w-4xl">
              <div className="inline-flex items-center gap-2 rounded-full border border-destaque/20 bg-azul-claro px-3 py-1.5 text-xs font-bold uppercase tracking-[0.14em] text-destaque">
                <LockKeyhole className="h-3.5 w-3.5" /> Conteúdo técnico autorizado
              </div>
              <h1 className="page-title mt-5">Detalhamento da metodologia de qualidade para atendimento</h1>
              <p className="page-lede mt-5">
                Pilares, critérios, pesos e regras são carregados somente após autenticação e autorização explícita.
              </p>
            </div>
            <div className="surface-card max-w-sm p-5">
              <p className="flex items-center gap-2 text-sm font-bold text-grafite"><ShieldCheck className="h-4 w-4 text-destaque" /> Regra de confidencialidade</p>
              <p className="mt-2 text-sm leading-6 text-muted-foreground">Nenhum dado de empresa, pessoa, protocolo, atendimento ou resultado real faz parte desta área.</p>
            </div>
          </div>
        </div>
      </header>

      <main>
        <section className="page-shell py-12 md:py-16">
          <MethodologyMap compact />
        </section>

        <section className="border-y border-border bg-white">
          <div className="page-shell py-12 md:py-16">
            {isLoading && (
              <div className="surface-card flex items-center gap-4 p-6" role="status">
                <span className="h-7 w-7 animate-spin rounded-full border-4 border-slate-200 border-t-destaque" />
                <p className="font-semibold text-grafite">Carregando conteúdo autorizado…</p>
              </div>
            )}

            {!isLoading && loadError && (
              <div className="surface-card p-6" role="alert">
                <p className="font-bold text-grafite">Conteúdo temporariamente indisponível</p>
                <p className="mt-2 text-sm leading-6 text-muted-foreground">{loadError}</p>
              </div>
            )}

            {!isLoading && !loadError && orderedRecords.length === 0 && (
              <div className="surface-card mx-auto max-w-2xl p-7 text-center md:p-10">
                <span className="mx-auto flex h-12 w-12 items-center justify-center rounded-2xl bg-azul-claro text-destaque">
                  <Database className="h-6 w-6" />
                </span>
                <h2 className="mt-5 text-2xl font-bold">Detalhamento ainda não publicado</h2>
                <p className="mt-3 text-base leading-7 text-muted-foreground">
                  Seu acesso está autorizado. O conteúdo técnico será exibido aqui assim que os registros forem cadastrados na base protegida.
                </p>
              </div>
            )}

            {!isLoading && !loadError && orderedRecords.length > 0 && (
              <div className="space-y-5">
                {orderedRecords.map((record) => <SectionCard key={record.id} record={record} />)}
              </div>
            )}
          </div>
        </section>

        <section className="page-shell py-12 md:py-16">
          <div className="surface-card flex flex-col gap-5 p-6 md:flex-row md:items-center md:justify-between md:p-8">
            <div className="max-w-2xl">
              <p className="flex items-center gap-2 text-sm font-bold text-destaque"><BookOpenCheck className="h-4 w-4" /> Fim do detalhamento</p>
              <h2 className="mt-2 text-2xl font-bold">Voltar para a apresentação pública</h2>
              <p className="mt-2 text-sm leading-6 text-muted-foreground">A página pública apresenta a visão geral da metodologia de forma clara e acessível.</p>
            </div>
            <Link to="/metodos" className="inline-flex min-h-11 shrink-0 items-center justify-center gap-2 rounded-xl bg-destaque px-5 py-3 text-sm font-bold text-white hover:bg-[#285fc3]">
              <ArrowLeft className="h-4 w-4" /> Métodos autorais
            </Link>
          </div>
        </section>
      </main>
    </div>
  );
}
