import React from "react";
import { Link } from "react-router-dom";
import { ArrowRight, BookOpen, Compass, Eye, Layers3, ShieldCheck } from "lucide-react";

const PRINCIPLES = [
  {
    title: "Clareza antes de volume",
    description: "Textos curtos, hierarquia visível e exemplos que ajudam a entender sem transformar a página em um manual extenso.",
    Icon: Eye,
  },
  {
    title: "Teoria ligada à aplicação",
    description: "Cada conceito deve responder o que é, quando usar, como aplicar e o que observar no resultado.",
    Icon: Layers3,
  },
  {
    title: "Privacidade por princípio",
    description: "A QualiPédia não publica dados de empresas, clientes, colaboradores, protocolos ou atendimentos reais.",
    Icon: ShieldCheck,
  },
];

export default function About() {
  return (
    <div className="pb-16 md:pb-24">
      <section className="border-b border-border bg-white">
        <div className="page-shell py-14 md:py-20">
          <p className="eyebrow">Sobre o projeto</p>
          <h1 className="page-title mt-4 max-w-4xl">Conhecimento em qualidade, organizado para ser usado</h1>
          <p className="page-lede mt-6">
            A QualiPédia é um projeto autoral de Bruna Silva Ramos criado para reunir repertório, aplicação prática e metodologias próprias em uma experiência de consulta simples e visual.
          </p>
        </div>
      </section>

      <section className="page-shell py-12 md:py-16">
        <div className="grid gap-5 lg:grid-cols-3">
          {PRINCIPLES.map(({ title, description, Icon }) => (
            <article key={title} className="surface-card p-6">
              <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-azul-claro text-destaque"><Icon className="h-5 w-5" /></span>
              <h2 className="mt-5 text-xl font-bold">{title}</h2>
              <p className="mt-3 text-base leading-7 text-muted-foreground">{description}</p>
            </article>
          ))}
        </div>
      </section>

      <section className="border-y border-border bg-white">
        <div className="page-shell grid gap-10 py-12 md:py-16 lg:grid-cols-2">
          <div>
            <p className="eyebrow">O que você encontra</p>
            <h2 className="mt-3 text-3xl font-bold md:text-4xl">Três formas de explorar</h2>
          </div>
          <div className="space-y-4">
            <Link to="/enciclopedia" className="surface-card group flex min-h-24 items-center gap-4 p-5 hover:border-destaque/35">
              <BookOpen className="h-6 w-6 shrink-0 text-destaque" />
              <div className="min-w-0 flex-1"><p className="font-bold">Aprender pela enciclopédia</p><p className="mt-1 text-sm text-muted-foreground">Conceitos, ferramentas, indicadores e processos.</p></div>
              <ArrowRight className="h-5 w-5 text-muted-foreground group-hover:text-destaque" />
            </Link>
            <Link to="/decisao" className="surface-card group flex min-h-24 items-center gap-4 p-5 hover:border-destaque/35">
              <Compass className="h-6 w-6 shrink-0 text-destaque" />
              <div className="min-w-0 flex-1"><p className="font-bold">Partir de um problema</p><p className="mt-1 text-sm text-muted-foreground">Use o guia de decisão para encontrar uma ferramenta.</p></div>
              <ArrowRight className="h-5 w-5 text-muted-foreground group-hover:text-destaque" />
            </Link>
            <Link to="/metodos" className="surface-card group flex min-h-24 items-center gap-4 p-5 hover:border-destaque/35">
              <Layers3 className="h-6 w-6 shrink-0 text-destaque" />
              <div className="min-w-0 flex-1"><p className="font-bold">Conhecer métodos autorais</p><p className="mt-1 text-sm text-muted-foreground">Veja como teoria, indicadores e desenvolvimento foram estruturados.</p></div>
              <ArrowRight className="h-5 w-5 text-muted-foreground group-hover:text-destaque" />
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
